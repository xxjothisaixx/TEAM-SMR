const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const multer = require('multer');
const path = require('path');
const app = express();

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

mongoose.connect('mongodb://127.0.0.1:27017/studentTeam', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log("MongoDB connected"))
  .catch(err => console.error(err));

const memberSchema = new mongoose.Schema({
    name: String,
    role: String,
    email: String,
    image: String
});

const Member = mongoose.model('Member', memberSchema);

const storage = multer.diskStorage({
    destination: 'uploads/',
    filename: (req, file, cb) => cb(null, Date.now() + path.extname(file.originalname))
});
const upload = multer({ storage });

app.post('/api/members', upload.single('image'), async (req, res) => {
    const { name, role, email } = req.body;
    const image = req.file.filename;
    const member = new Member({ name, role, email, image });
    await member.save();
    res.status(201).json(member);
});

app.get('/api/members', async (req, res) => {
    const members = await Member.find();
    res.json(members);
});

app.get('/api/members/:id', async (req, res) => {
    const member = await Member.findById(req.params.id);
    res.json(member);
});

app.listen(5000, () => console.log('Server running on port 5000'));
