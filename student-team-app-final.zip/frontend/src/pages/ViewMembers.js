import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const ViewMembers = () => {
  const [members, setMembers] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:5000/api/members')
      .then(res => setMembers(res.data));
  }, []);

  return (
    <div>
      <h2>Team Members</h2>
      {members.map(member => (
        <div key={member._id}>
          <img src={'http://localhost:5000/uploads/' + member.image} width="100" alt="" />
          <p>{member.name} - {member.role}</p>
          <Link to={`/members/${member._id}`}>View Details</Link>
        </div>
      ))}
    </div>
  );
};

export default ViewMembers;
