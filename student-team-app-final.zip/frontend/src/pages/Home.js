import React from 'react';
import { Link } from 'react-router-dom';

const Home = () => (
  <div>
    <h2>Welcome to Team SMR Management App</h2>
    <p>This app helps manage team members: Sai, Maxi, Rubesh</p>
    <Link to="/add"><button>Add Member</button></Link>
    <Link to="/members"><button>View Members</button></Link>
  </div>
);

export default Home;
